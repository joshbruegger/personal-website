import{a as t}from"../chunks/entry.DWoHIw-O.js";export{t as start};
