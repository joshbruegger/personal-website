import * as universal from '../entries/pages/_page.ts.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+page.ts";
export const imports = ["_app/immutable/nodes/2.B3fTDNhl.js","_app/immutable/chunks/scheduler.D0YMBEEH.js","_app/immutable/chunks/index.c6KgA6PU.js","_app/immutable/chunks/store.CnPCZZTZ.js","_app/immutable/chunks/index.D_hvs9jT.js"];
export const stylesheets = ["_app/immutable/assets/2.BNHXngYt.css","_app/immutable/assets/store.CcBojqxD.css"];
export const fonts = [];
