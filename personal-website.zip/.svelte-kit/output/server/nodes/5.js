

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/projects/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.BgAnEfuS.js","_app/immutable/chunks/scheduler.D0YMBEEH.js","_app/immutable/chunks/index.c6KgA6PU.js","_app/immutable/chunks/each.D6YF6ztN.js"];
export const stylesheets = ["_app/immutable/assets/5.CNFoIqnH.css"];
export const fonts = [];
