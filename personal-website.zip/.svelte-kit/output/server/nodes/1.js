

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.ds5EThNp.js","_app/immutable/chunks/scheduler.D0YMBEEH.js","_app/immutable/chunks/index.c6KgA6PU.js"];
export const stylesheets = ["_app/immutable/assets/1.BH_BM0Ug.css"];
export const fonts = [];
