

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/privacy-policy/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.CpbUB7DW.js","_app/immutable/chunks/scheduler.D0YMBEEH.js","_app/immutable/chunks/index.c6KgA6PU.js","_app/immutable/chunks/Constants.CAFUE90l.js"];
export const stylesheets = ["_app/immutable/assets/3.BHacQ0Mr.css"];
export const fonts = [];
