import { c as create_ssr_component, b as each, e as escape } from "../../../chunks/ssr.js";
const skills = {
  programming: ["Python", "Flutter", "Dart", "Typescript", "Svelte.js", "R"],
  design: ["Figma", "Illustrator", "Photoshop", "InDesign"],
  editing: ["Davinci Resolve"],
  languages: ["Italian", "English", "(some) Spanish", "(some) Dutch"]
  // other: ['Design principles', 'User interface design']
};
const css = {
  code: ".container.svelte-94kywl.svelte-94kywl{max-width:900px;padding:0;display:flex;justify-content:center}main.svelte-94kywl.svelte-94kywl{max-width:90%;min-height:500px;text-align:left;margin:0 auto;box-sizing:border-box}h1.svelte-94kywl.svelte-94kywl{font-weight:700;margin:0 0 50px 0;font-size:36px;text-align:start}h2.svelte-94kywl.svelte-94kywl{margin-top:50px}.list.svelte-94kywl.svelte-94kywl{display:flex;flex-direction:column;gap:30px}@media(min-width: 900px){.list.svelte-94kywl.svelte-94kywl{flex-direction:row}main.svelte-94kywl>h1.svelte-94kywl{font-size:48px}}",
  map: `{"version":3,"file":"+page.svelte","sources":["+page.svelte"],"sourcesContent":["<script>\\n\\timport skills from '$lib/Skills';\\n<\/script>\\n\\n<svelte:head>\\n\\t<title>Josh Bruegger — About</title>\\n</svelte:head>\\n\\n<div class=\\"container\\">\\n\\t<main>\\n\\t\\t<h1>About</h1>\\n\\t\\t<p>\\n\\t\\t\\tI'm a motivated Energy and Environmental Sciences Master's student with a Bachelor's degree in\\n\\t\\t\\tArtificial Intelligence at the University of Groningen. I'm based in Groningen, The\\n\\t\\t\\tNetherlands, and I am currently working as a student assistant at the university's Green\\n\\t\\t\\tOffice, where I'm responsible for contact with Student Organisations.\\n\\t\\t</p>\\n\\t\\t<h2>Skills</h2>\\n\\t\\t{#each Object.entries(skills) as [section, items]}\\n\\t\\t\\t<ul>\\n\\t\\t\\t\\t<li>\\n\\t\\t\\t\\t\\t<h4>\\n\\t\\t\\t\\t\\t\\t{section}:\\n\\t\\t\\t\\t\\t</h4>\\n\\t\\t\\t\\t\\t<ul class=\\"list\\">\\n\\t\\t\\t\\t\\t\\t{#each items as item}\\n\\t\\t\\t\\t\\t\\t\\t<li>\\n\\t\\t\\t\\t\\t\\t\\t\\t{item}\\n\\t\\t\\t\\t\\t\\t\\t</li>\\n\\t\\t\\t\\t\\t\\t{/each}\\n\\t\\t\\t\\t\\t</ul>\\n\\t\\t\\t\\t</li>\\n\\t\\t\\t</ul>\\n\\t\\t{/each}\\n\\t</main>\\n</div>\\n\\n<style>\\n\\t.container {\\n\\t\\tmax-width: 900px;\\n\\t\\tpadding: 0;\\n\\t\\tdisplay: flex;\\n\\t\\tjustify-content: center;\\n\\t}\\n\\n\\tmain {\\n\\t\\tmax-width: 90%;\\n\\t\\tmin-height: 500px;\\n\\t\\ttext-align: left;\\n\\t\\tmargin: 0 auto;\\n\\t\\tbox-sizing: border-box;\\n\\t}\\n\\n\\th1 {\\n\\t\\tfont-weight: 700;\\n\\t\\tmargin: 0 0 50px 0;\\n\\t\\tfont-size: 36px;\\n\\t\\ttext-align: start;\\n\\t}\\n\\n\\th2 {\\n\\t\\tmargin-top: 50px;\\n\\t}\\n\\n\\t.list {\\n\\t\\tdisplay: flex;\\n\\t\\tflex-direction: column;\\n\\t\\tgap: 30px;\\n\\t}\\n\\n\\t@media (min-width: 900px) {\\n\\t\\t.list {\\n\\t\\t\\tflex-direction: row;\\n\\t\\t}\\n\\t\\tmain > h1 {\\n\\t\\t\\tfont-size: 48px;\\n\\t\\t}\\n\\t}\\n</style>\\n"],"names":[],"mappings":"AAsCC,sCAAW,CACV,SAAS,CAAE,KAAK,CAChB,OAAO,CAAE,CAAC,CACV,OAAO,CAAE,IAAI,CACb,eAAe,CAAE,MAClB,CAEA,gCAAK,CACJ,SAAS,CAAE,GAAG,CACd,UAAU,CAAE,KAAK,CACjB,UAAU,CAAE,IAAI,CAChB,MAAM,CAAE,CAAC,CAAC,IAAI,CACd,UAAU,CAAE,UACb,CAEA,8BAAG,CACF,WAAW,CAAE,GAAG,CAChB,MAAM,CAAE,CAAC,CAAC,CAAC,CAAC,IAAI,CAAC,CAAC,CAClB,SAAS,CAAE,IAAI,CACf,UAAU,CAAE,KACb,CAEA,8BAAG,CACF,UAAU,CAAE,IACb,CAEA,iCAAM,CACL,OAAO,CAAE,IAAI,CACb,cAAc,CAAE,MAAM,CACtB,GAAG,CAAE,IACN,CAEA,MAAO,YAAY,KAAK,CAAE,CACzB,iCAAM,CACL,cAAc,CAAE,GACjB,CACA,kBAAI,CAAG,gBAAG,CACT,SAAS,CAAE,IACZ,CACD"}`
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `${$$result.head += `<!-- HEAD_svelte-17dttka_START -->${$$result.title = `<title>Josh Bruegger — About</title>`, ""}<!-- HEAD_svelte-17dttka_END -->`, ""} <div class="container svelte-94kywl"><main class="svelte-94kywl"><h1 class="svelte-94kywl" data-svelte-h="svelte-soqi9t">About</h1> <p data-svelte-h="svelte-12gbfot">I&#39;m a motivated Energy and Environmental Sciences Master&#39;s student with a Bachelor&#39;s degree in
			Artificial Intelligence at the University of Groningen. I&#39;m based in Groningen, The
			Netherlands, and I am currently working as a student assistant at the university&#39;s Green
			Office, where I&#39;m responsible for contact with Student Organisations.</p> <h2 class="svelte-94kywl" data-svelte-h="svelte-1w8bmy8">Skills</h2> ${each(Object.entries(skills), ([section, items]) => {
    return `<ul><li><h4>${escape(section)}:</h4> <ul class="list svelte-94kywl">${each(items, (item) => {
      return `<li>${escape(item)} </li>`;
    })} </ul></li> </ul>`;
  })}</main> </div>`;
});
export {
  Page as default
};
