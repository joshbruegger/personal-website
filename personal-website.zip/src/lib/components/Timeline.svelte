<script>
  export let entries = [
    { date: '2020', description: 'Graduated from University' },
    { date: '2021', description: 'Started AI research' },
    { date: '2022', description: 'Published first paper' }
  ];
</script>

<div class="timeline-container">
  {#each entries as entry}
    <div class="entry">
      <div class="date">{entry.date}</div>
      <div class="description">{entry.description}</div>
    </div>
  {/each}
</div>

<style>
  .timeline-container {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    color: white;
  }

  .entry {
    position: relative;
    margin: 1.5em 0;
    padding-left: 1em;
    border-left: 3px solid #ca3c25;
    cursor: pointer;
  }

  .entry:hover .description {
    color: #ca3c25;
    transition: color 0.2s ease-in-out;
  }

  .date {
    font-weight: bold;
    margin-bottom: 0.5em;
  }
</style>