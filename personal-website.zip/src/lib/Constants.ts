export const ArticleEndPoint = 'https://dev.to/api/articles';
export const UserInfoEndpoint = 'https://dev.to/api/articles?username=';
export const MediumFeedEndpoint = 'https://medium.com/feed/';
export const Email = 'hi@joshbruegger.com';
