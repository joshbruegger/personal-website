const skills = {
	programming: ['Python', 'Flutter', 'Dart', 'Typescript', 'Svelte.js', 'R'],
	design: ['Figma', 'Illustrator', 'Photoshop', 'InDesign'],
	editing: ['Davinci Resolve'],
	languages: ['Italian', 'English', '(some) Spanish', '(some) Dutch'],
	// other: ['Design principles', 'User interface design']
};

export default skills;