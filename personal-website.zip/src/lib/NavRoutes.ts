const routes = [
	{ href: '/', label: 'Home' },
	{ href: '/about', label: 'About' },
	{ href: '/projects', label: 'Projects' },
	{ href: '/publications', label: 'Publications' },
	{ href: '/award', label: 'Award' },
	{ href: '/agentic-ai-project', label: 'Agentic AI Project' },
	{ href: '/timeline', label: 'Timeline' }
];

export default routes;
