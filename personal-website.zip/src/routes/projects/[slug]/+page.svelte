<script context="module" lang="ts">
  import { error } from '@sveltejs/kit';
  import projects from '$lib/Projects';
  export function load({ params }) {
    const project = projects.find((p) => p.slug === params.slug);
    if (!project) {
      throw error(404, 'Project not found');
    }
    return { project };
  }
</script>

<script lang="ts">
  export let data;
  const { project } = data;
</script>

<svelte:head>
  <title>Josh Bruegger — {project.title}</title>
</svelte:head>

<div class="pageContainer">
  <h1>{project.title}</h1>
  <div class="techsContainer">
    <h2>Technologies:</h2>
    <ul>
      {#each project.technologies as tech}
        <li>{tech}</li>
      {/each}
    </ul>
  </div>
  <p>{project.description}</p>
  <p>
    <a href={project.url} target="_blank" rel="noopener noreferrer">Project Link</a>
  </p>
  <p>
    <a href="/projects">← Back to Projects</a>
  </p>
</div>

<style>
  .pageContainer {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    padding: 1em;
    box-sizing: border-box;
    color: white;
    text-align: start;
  }
  h1 {
    margin-bottom: 1rem;
  }
  .techsContainer {
    margin-bottom: 1rem;
  }
  ul {
    padding-left: 1.5rem;
  }
  a {
    color: #ca3c25;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
</style>