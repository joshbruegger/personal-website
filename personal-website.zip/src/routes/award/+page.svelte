<svelte:head>
  <title>Josh Bruegger — Award</title>
</svelte:head>

<div class="pageContainer">
  <h1>Award</h1>
  <p>
    Nomination: <strong>Student of the year 2025</strong> by <em>EVOStar</em>.
  </p>
</div>

<style>
  .pageContainer {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    padding: 1em;
    box-sizing: border-box;
    text-align: start;
    color: white;
  }
  h1 {
    margin-bottom: 1rem;
  }
  p {
    font-size: 1.1rem;
  }
</style>