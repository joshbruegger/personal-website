<svelte:head>
  <title>Josh Bruegger — Agentic AI Project</title>
</svelte:head>

<div class="pageContainer">
  <h1>Agentic AI Project</h1>
  <p>This is a placeholder description for the Agentic AI project. Details will be added soon.</p>
  <p><a href="#" target="_blank" rel="noreferrer">Project Link (placeholder)</a></p>
</div>

<style>
  .pageContainer {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    padding: 1em;
    box-sizing: border-box;
    text-align: start;
    color: white;
  }
  h1 {
    margin-bottom: 1rem;
  }
  a {
    color: #ca3c25;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
</style>