<script lang="ts">
  import Timeline from '$lib/components/Timeline.svelte';
</script>

<svelte:head>
  <title>Josh Bruegger — Timeline</title>
</svelte:head>

<div class="pageContainer">
  <h1>Timeline</h1>
  <Timeline />
</div>

<style>
  .pageContainer {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    padding: 1em;
    box-sizing: border-box;
    text-align: start;
    color: white;
  }
  h1 {
    margin-bottom: 1rem;
  }
</style>