<svelte:head>
  <title>Josh Bruegger — Publications</title>
</svelte:head>

<div class="pageContainer">
  <h1>Publications</h1>
  <ul>
    <li>
      <a href="#" target="_blank" rel="noopener noreferrer">
        Placeholder Publication Title
      </a> (long talk at EvoMUSART)
    </li>
  </ul>
</div>

<style>
  .pageContainer {
    width: 90%;
    max-width: 900px;
    margin: 0 auto;
    padding: 1em;
    box-sizing: border-box;
    text-align: start;
    color: white;
  }
  h1 {
    margin-bottom: 1rem;
  }
  ul {
    list-style: disc;
    padding-left: 1.5rem;
  }
  a {
    color: #ca3c25;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
</style>